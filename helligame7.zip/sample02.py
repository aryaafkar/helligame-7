#speed
import helligame as game
game.Box( (350,250) , (100,40) , game.BLUE, (10, 0) )
game.Label(0, (35,20))
game.mainloop()
