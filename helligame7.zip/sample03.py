#use argument name
import helligame as game
game.Box( position=(350,250) , size=(100,40) , color=game.BLUE, speed=(10, 0) )
game.Label(0, position=(35,20))
game.mainloop()
