import helligame as game
game.Box( (350,250) , (100,40) )
game.mainloop()
